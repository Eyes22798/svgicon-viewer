const e="こんにちは、{name}！",n="言語",a={home:"ホーム"},o={hello:e,language:n,menu:a};export{o as default,e as hello,n as language,a as menu};
