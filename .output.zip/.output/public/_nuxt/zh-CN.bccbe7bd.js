const e="你好, {name}!",n="语言",o={home:"首页"},a={hello:e,language:n,menu:o};export{a as default,e as hello,n as language,o as menu};
