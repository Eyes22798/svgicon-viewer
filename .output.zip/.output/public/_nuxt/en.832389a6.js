const e="Hello, {name}!",n="Language",o={home:"Home"},a={hello:e,language:n,menu:o};export{a as default,e as hello,n as language,o as menu};
