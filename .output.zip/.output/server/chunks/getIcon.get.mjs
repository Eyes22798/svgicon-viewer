import { d as defineEventHandler } from './nitro/node-server.mjs';
import fs from 'fs-extra';
import yargs from 'yargs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'fs';
import 'node:fs';
import 'node:url';

async function readFilesRecursive(folderPath) {
  try {
    const entries = await fs.readdir(folderPath, { withFileTypes: true });
    const results = await Promise.all(
      entries.map(async (entry) => {
        var _a;
        const fullPath = path.join(folderPath, entry.name);
        if (entry.isDirectory()) {
          return readFilesRecursive(fullPath);
        } else {
          if (path.extname(entry.name).toLowerCase() === ".svg") {
            const content = await fs.readFile(fullPath, "utf8");
            const fileName = (_a = entry.name.split("/").pop()) != null ? _a : "";
            const name = fileName.split(".").slice(0, -1).join(".");
            return { name, content, fullPath, sep: path.sep };
          } else {
            return {};
          }
        }
      })
    );
    return results.filter((result) => Object.keys(result).length > 0);
  } catch (err) {
    console.error(`Error reading folder ${folderPath}:`, err);
  }
}
const svgPath = yargs(process.argv.slice(2)).argv.path;
const getIcon_get = defineEventHandler(async (event) => {
  const files = await readFilesRecursive(svgPath);
  return files;
});

export { getIcon_get as default };
//# sourceMappingURL=getIcon.get.mjs.map
