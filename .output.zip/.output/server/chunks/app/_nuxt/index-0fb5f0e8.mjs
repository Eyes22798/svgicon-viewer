import { defineComponent, createVNode, useSSRContext, ref, computed, watch, mergeProps, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, unref, withAsyncContext, toRaw, toValue, reactive, shallowRef, toRef, getCurrentInstance, onServerPrefetch } from 'vue';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { optimize } from 'svgo';
import { t as hash } from '../../nitro/node-server.mjs';
import { f as fetchDefaults, d as asyncDataDefaults, e as useNuxtApp, c as createError } from '../server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue-i18n';

function useAsyncData(...args) {
  var _a2, _b, _c, _d, _e, _f, _g, _h;
  var _a;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  const nuxt = useNuxtApp();
  const getDefault = () => null;
  const getDefaultCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
  options.server = (_a2 = options.server) != null ? _a2 : true;
  options.default = (_b = options.default) != null ? _b : getDefault;
  options.getCachedData = (_c = options.getCachedData) != null ? _c : getDefaultCachedData;
  options.lazy = (_d = options.lazy) != null ? _d : false;
  options.immediate = (_e = options.immediate) != null ? _e : true;
  options.deep = (_f = options.deep) != null ? _f : asyncDataDefaults.deep;
  const hasCachedData = () => ![null, void 0].includes(options.getCachedData(key));
  if (!nuxt._asyncData[key] || !options.immediate) {
    (_g = (_a = nuxt.payload._errors)[key]) != null ? _g : _a[key] = null;
    const _ref = options.deep ? ref : shallowRef;
    nuxt._asyncData[key] = {
      data: _ref((_h = options.getCachedData(key)) != null ? _h : options.default()),
      pending: ref(!hasCachedData()),
      error: toRef(nuxt.payload._errors, key),
      status: ref("idle")
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      if (opts.dedupe === false) {
        return nuxt._asyncDataPromises[key];
      }
      nuxt._asyncDataPromises[key].cancelled = true;
    }
    if ((opts._initial || nuxt.isHydrating && opts._initial !== false) && hasCachedData()) {
      return Promise.resolve(options.getCachedData(key));
    }
    asyncData.pending.value = true;
    asyncData.status.value = "pending";
    const promise = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((_result) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      let result = _result;
      if (options.transform) {
        result = options.transform(_result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      nuxt.payload.data[key] = result;
      asyncData.data.value = result;
      asyncData.error.value = null;
      asyncData.status.value = "success";
    }).catch((error) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      asyncData.error.value = createError(error);
      asyncData.data.value = unref(options.default());
      asyncData.status.value = "error";
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      delete nuxt._asyncDataPromises[key];
    });
    nuxt._asyncDataPromises[key] = promise;
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    if (getCurrentInstance()) {
      onServerPrefetch(() => promise);
    } else {
      nuxt.hook("app:created", async () => {
        await promise;
      });
    }
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useRequestEvent(nuxtApp = useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
function useRequestFetch() {
  var _a;
  return ((_a = useRequestEvent()) == null ? void 0 : _a.$fetch) || globalThis.$fetch;
}
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _request = computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return toValue(r);
  });
  const _key = opts.key || hash([autoKey, typeof _request.value === "string" ? _request.value : "", ...generateOptionSegments(opts)]);
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = _key === autoKey ? "$f" + _key : _key;
  if (!opts.baseURL && typeof _request.value === "string" && _request.value.startsWith("//")) {
    throw new Error('[nuxt] [useFetch] the request URL must not start with "//".');
  }
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2,
    immediate,
    getCachedData,
    deep,
    ...fetchOptions
  } = opts;
  const _fetchOptions = reactive({
    ...fetchDefaults,
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    immediate,
    getCachedData,
    deep,
    watch: watch2 === false ? [] : [_fetchOptions, _request, ...watch2 || []]
  };
  let controller;
  const asyncData = useAsyncData(key, () => {
    var _a;
    (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller);
    controller = typeof AbortController !== "undefined" ? new AbortController() : {};
    const timeoutLength = toValue(opts.timeout);
    if (timeoutLength) {
      setTimeout(() => controller.abort(), timeoutLength);
    }
    let _$fetch = opts.$fetch || globalThis.$fetch;
    if (!opts.$fetch) {
      const isLocalFetch = typeof _request.value === "string" && _request.value.startsWith("/") && (!toValue(opts.baseURL) || toValue(opts.baseURL).startsWith("/"));
      if (isLocalFetch) {
        _$fetch = useRequestFetch();
      }
    }
    return _$fetch(_request.value, { signal: controller.signal, ..._fetchOptions });
  }, _asyncDataOptions);
  return asyncData;
}
function generateOptionSegments(opts) {
  var _a;
  const segments = [
    ((_a = toValue(opts.method)) == null ? void 0 : _a.toUpperCase()) || "GET",
    toValue(opts.baseURL)
  ];
  for (const _obj of [opts.params || opts.query]) {
    const obj = toValue(_obj);
    if (!obj) {
      continue;
    }
    const unwrapped = {};
    const iterator = Array.isArray(obj) ? obj : Object.entries(obj);
    for (const [key, value] of iterator) {
      unwrapped[toValue(key)] = toValue(value);
    }
    segments.push(unwrapped);
  }
  return segments;
}
function ssrRegisterHelper(comp, filename) {
  const setup = comp.setup;
  comp.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add(filename);
    if (setup) {
      return setup(props, ctx);
    }
  };
}
const __default__$1 = defineComponent({
  name: "Sidebar",
  model: {
    prop: "modelValue",
    event: "input"
  },
  props: {
    modelValue: {
      type: String,
      default: ""
    },
    reduce: {
      default: false
    },
    hoverExpand: {
      default: false
    },
    open: {
      default: false
    },
    notLineActive: {
      default: false
    },
    square: {
      default: false
    },
    textWhite: {
      default: false
    },
    notShadow: {
      default: false
    },
    relative: {
      default: false
    },
    absolute: {
      default: false
    },
    right: {
      default: false
    },
    background: {
      default: "background"
    }
  },
  data() {
    return {
      staticWidth: 260,
      forceExpand: false,
      reduceInternal: false
    };
  },
  watch: {
    open: {
      handler() {
        if (this.open) {
          window.addEventListener("click", this.clickCloseSidebar);
        } else {
          window.removeEventListener("click", this.clickCloseSidebar);
        }
      }
    },
    reduce: {
      handler() {
        this.reduceInternal = this.reduce;
        this.$el.style.width = this.reduce ? "50px" : `${this.staticWidth}px`;
      }
    },
    reduceInternal: {
      handler() {
        this.$el.style.width = this.reduceInternal ? "50px" : `${this.staticWidth}px`;
      }
    },
    background: {
      handler() {
        this.$el.style.backgroundColor = this.background;
      }
    }
  },
  mounted() {
    this.staticWidth = this.$el.offsetWidth;
    this.reduceInternal = this.reduce;
    if (this.background !== "background") {
      this.$el.style.backgroundColor = this.background;
    }
    if (this.textWhite) {
      this.$el.style.color = "#fff";
    }
  },
  methods: {
    getValue() {
      return this.modelValue;
    },
    clickCloseSidebar(evt) {
      if (!evt.target.closest(".vs-sidebar-content")) {
        this.$emit("update:modelValue", false);
      }
    },
    handleClickItem(id) {
      this.$emit("update:modelValue", id);
    }
  },
  render() {
    const logo = this.$slots.logo ? this.$slots.logo() : null;
    const header = this.$slots.header ? this.$slots.header() : null;
    const footer = this.$slots.footer ? this.$slots.footer() : null;
    const sidebar = this.$slots.default ? this.$slots.default() : null;
    return createVNode("div", {
      "style": this.$attrs.style,
      "class": ["vs-sidebar", "vs-sidebar-content", {
        reduce: this.reduceInternal,
        open: this.open,
        notLineActive: this.notLineActive,
        square: this.square,
        notShadow: this.notShadow,
        textWhite: this.textWhite,
        relative: this.relative,
        absolute: this.absolute,
        right: this.right
      }],
      "on": this.$attrs.on
    }, [logo, header, sidebar, footer]);
  }
});
const _sfc_main$6 = __default__$1;
const __moduleId$1 = "components/sidebar.vue?vue&type=script&lang.jsx";
ssrRegisterHelper(__default__$1, __moduleId$1);
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/sidebar.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-08a644b1"]]);
const __default__ = defineComponent({
  props: {
    to: {
      type: String,
      default: ""
    },
    href: {
      type: String,
      default: ""
    },
    target: {
      type: String,
      default: "_blank"
    },
    value: {
      type: String,
      default: ""
    },
    id: {
      type: String,
      default: ""
    },
    arrow: {
      type: Boolean,
      default: false
    }
  },
  setup(props) {
    const isActive = ref(false);
    const handleClick = () => {
      if (props.to) {
        this.$router.push(props.to);
      } else if (props.href) {
        window.open(props.href, props.target);
      }
    };
    return {
      isActive,
      handleClick
    };
  },
  render() {
    var _a, _b;
    const icon = createVNode("div", {
      "class": "vs-sidebar__item__icon"
    }, [this.$slots.icon && this.$slots.icon()]);
    const textTooltip = createVNode("div", {
      "class": "vs-sidebar__item__text-tooltip"
    }, [this.$slots.default()]);
    const text = createVNode("div", {
      "class": "vs-sidebar__item__text"
    }, [this.$slots.default()]);
    const arrow = this.$slots.arrow;
    return createVNode("button", {
      "class": {
        active: ((_a = this.$parent) == null ? void 0 : _a.getValue) && this.id === ((_b = this.$parent) == null ? void 0 : _b.getValue()),
        hasIcon: !!this.$slots.icon,
        "vs-sidebar__item": true
      },
      "onClick": () => {
        if (this.id) {
          this.$parent.handleClickItem(this.id);
        }
        this.handleClick();
      }
    }, [this.$slots.icon && icon, text, textTooltip, this.$slots.arrow || this.arrow && arrow]);
  }
});
const _sfc_main$5 = __default__;
const __moduleId = "components/sidebar-item.vue?vue&type=script&lang.jsx";
ssrRegisterHelper(__default__, __moduleId);
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/sidebar-item.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-de966418"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "left",
  __ssrInlineRender: true,
  props: {
    allIcons: { type: Array, default: [] }
  },
  emits: ["left-change"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const groups = computed(() => {
      const groupByDirectory = (data) => {
        const result = {};
        for (let i = 0; i < data.length; i++) {
          const path = data[i].fullPath;
          const parts = path.split(data[i].sep);
          const directory = parts[parts.length - 2];
          const icon = data[i].name;
          if (result[directory]) {
            result[directory].push(icon);
          } else {
            result[directory] = [icon];
          }
        }
        return result;
      };
      return groupByDirectory(props.allIcons);
    });
    const active = ref("home");
    watch(() => active.value, () => {
      emit("left-change", active.value, groups.value[active.value]);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_sidebar = __nuxt_component_0;
      const _component_sidebar_item = __nuxt_component_1$1;
      _push(ssrRenderComponent(_component_sidebar, mergeProps({
        absolute: true,
        modelValue: active.value,
        "onUpdate:modelValue": ($event) => active.value = $event,
        open: true
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_sidebar_item, { id: "home" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` \u5168\u90E8\uFF08${ssrInterpolate(__props.allIcons.length)}\uFF09 `);
                } else {
                  return [
                    createTextVNode(" \u5168\u90E8\uFF08" + toDisplayString(__props.allIcons.length) + "\uFF09 ", 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<!--[-->`);
            ssrRenderList(Object.keys(groups.value), (key, index2) => {
              _push2(ssrRenderComponent(_component_sidebar_item, {
                key: index2,
                id: key
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(key)} \uFF08${ssrInterpolate(groups.value[key].length)}\uFF09`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(key) + " \uFF08" + toDisplayString(groups.value[key].length) + "\uFF09", 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              createVNode(_component_sidebar_item, { id: "home" }, {
                default: withCtx(() => [
                  createTextVNode(" \u5168\u90E8\uFF08" + toDisplayString(__props.allIcons.length) + "\uFF09 ", 1)
                ]),
                _: 1
              }),
              (openBlock(true), createBlock(Fragment, null, renderList(Object.keys(groups.value), (key, index2) => {
                return openBlock(), createBlock(_component_sidebar_item, {
                  key: index2,
                  id: key
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(key) + " \uFF08" + toDisplayString(groups.value[key].length) + "\uFF09", 1)
                  ]),
                  _: 2
                }, 1032, ["id"]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/left.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "NuxtInput",
  __ssrInlineRender: true,
  props: {
    placeholder: { type: String, default: "" },
    modelValue: { type: String, default: "" }
  },
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "vs-input-parent vs-input-parent--state-null vs-component--dark vs-component--is-color",
        placeholder: __props.placeholder
      }, _attrs))} data-v-5962b004><div class="vs-input-content vs-input-content--has-color" data-v-5962b004><input placeholder="" id="vs-input--8" class="vs-input" autocomplete="off"${ssrRenderAttr("value", __props.modelValue)} data-v-5962b004>`);
      if (!__props.modelValue) {
        _push(`<label for="vs-input--8" class="vs-input__label" data-v-5962b004>${ssrInterpolate(__props.placeholder)}</label>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="vs-input__affects" data-v-5962b004><div class="vs-input__affects__1" data-v-5962b004></div><div class="vs-input__affects__2" data-v-5962b004></div><div class="vs-input__affects__3" data-v-5962b004></div><div class="vs-input__affects__4" data-v-5962b004></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/NuxtInput.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-5962b004"]]);
const presetDefault = [
  {
    name: "preset-default",
    params: {
      overrides: {
        removeViewBox: false
      }
    }
  },
  "cleanupListOfValues"
];
const optimizeSvg = (files) => {
  const optimizedSvgData = [];
  for (const file of files) {
    const svgData = optimize(file.content, { path: "path-to.svg", plugins: presetDefault });
    optimizedSvgData.push({
      name: file.name,
      content: svgData.data
    });
  }
  return Promise.all(optimizedSvgData);
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "view-list",
  __ssrInlineRender: true,
  props: {
    icons: { type: Array, default: [] }
  },
  setup(__props) {
    const props = __props;
    let list = ref(props.icons);
    watch(
      () => props.icons,
      async () => {
        const data = await optimizeSvg(props.icons);
        list.value = data;
      },
      {
        immediate: true,
        deep: true
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "page-section" }, _attrs))}><div class="icon-list"><!--[-->`);
      ssrRenderList(unref(list), (v) => {
        _push(`<div class="icon-item"><div class="icon">${v.content}</div><p class="icon-name">${ssrInterpolate(v.name)} <br></p><button class="btn">${ssrInterpolate(v.copyTxt || "Copy")}</button></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/view-list.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "view-main",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const query = ref("");
    const iconGroups = ref([]);
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/getIcon", "$Hbj0Kkwpim")), __temp = await __temp, __restore(), __temp);
    const allIcons = [];
    data.value.forEach((groups) => {
      if (groups instanceof Array) {
        groups.forEach((icon) => {
          allIcons.push(toRaw(icon));
        });
      } else {
        allIcons.push(toRaw(groups));
      }
    });
    const icons = computed(() => {
      if (query.value) {
        return allIcons.filter((v) => {
          return v.name.includes(query.value);
        });
      }
      if (iconGroups.value.length > 0) {
        return iconGroups.value;
      }
      return allIcons;
    });
    const handleLeftChange = (value, arr) => {
      if (value === "home") {
        iconGroups.value = allIcons;
      } else {
        const filterIcons = [];
        arr.forEach((item) => {
          filterIcons.push(allIcons.find((icon) => icon.name === item));
        });
        iconGroups.value = filterIcons;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_left = _sfc_main$4;
      const _component_nuxt_input = __nuxt_component_1;
      const _component_view_list = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "app" }, _attrs))}><aside>`);
      _push(ssrRenderComponent(_component_left, {
        allIcons,
        onLeftChange: handleLeftChange
      }, null, _parent));
      _push(`</aside><main><h2>SVG ICON LIST VIEW</h2><div class="header-search">`);
      _push(ssrRenderComponent(_component_nuxt_input, {
        modelValue: query.value,
        "onUpdate:modelValue": ($event) => query.value = $event,
        placeholder: "\u641C\u7D22"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_view_list, { icons: icons.value }, null, _parent));
      _push(`</main></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/view-main.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_view_main = _sfc_main$1;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_view_main, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-0fb5f0e8.mjs.map
