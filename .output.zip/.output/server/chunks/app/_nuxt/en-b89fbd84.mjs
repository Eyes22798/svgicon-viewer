const hello = "Hello, {name}!";
const language = "Language";
const menu = {
  home: "Home"
};
const en = {
  hello,
  language,
  menu
};

export { en as default, hello, language, menu };
//# sourceMappingURL=en-b89fbd84.mjs.map
