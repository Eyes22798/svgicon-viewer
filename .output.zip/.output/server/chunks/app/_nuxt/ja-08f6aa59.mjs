const hello = "\u3053\u3093\u306B\u3061\u306F\u3001{name}\uFF01";
const language = "\u8A00\u8A9E";
const menu = {
  home: "\u30DB\u30FC\u30E0"
};
const ja = {
  hello,
  language,
  menu
};

export { ja as default, hello, language, menu };
//# sourceMappingURL=ja-08f6aa59.mjs.map
