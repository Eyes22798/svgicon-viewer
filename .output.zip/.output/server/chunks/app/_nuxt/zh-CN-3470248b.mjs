const hello = "\u4F60\u597D, {name}!";
const language = "\u8BED\u8A00";
const menu = {
  home: "\u9996\u9875"
};
const zhCN = {
  hello,
  language,
  menu
};

export { zhCN as default, hello, language, menu };
//# sourceMappingURL=zh-CN-3470248b.mjs.map
