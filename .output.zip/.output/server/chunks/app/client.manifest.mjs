const client_manifest = {
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_vue.f36acd1f.fc5ee1b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.fc5ee1b1.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "locales/en.json": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "en.832389a6.js",
    "isDynamicEntry": true,
    "src": "locales/en.json"
  },
  "locales/ja.json": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ja.1a729e25.js",
    "isDynamicEntry": true,
    "src": "locales/ja.json"
  },
  "locales/zh-CN.json": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "zh-CN.bccbe7bd.js",
    "isDynamicEntry": true,
    "src": "locales/zh-CN.json"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7b8544b4.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.4ea405d7.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.fc5ee1b1.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7b8544b4.css": {
    "file": "error-404.7b8544b4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.cbe832a1.css",
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.0a959a90.js",
    "imports": [
      "_vue.f36acd1f.fc5ee1b1.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.cbe832a1.css": {
    "file": "error-500.cbe832a1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.d333567a.css",
    "src": "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.d333567a.css"
    ],
    "dynamicImports": [
      "locales/en.json",
      "locales/ja.json",
      "locales/zh-CN.json",
      "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.739818fe.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.d333567a.css": {
    "file": "entry.d333567a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.92ab8c75.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.c1e56d98.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.8.2_sass@1.69.5_vite@4.5.1/node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.92ab8c75.css": {
    "file": "index.92ab8c75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
